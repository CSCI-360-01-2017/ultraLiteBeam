package com.csci360.alarmclock;

import java.util.Calendar;

/**
 *
 * @author Miki
 */
public class clockView {
    
    public void viewClock(theClock view) {
        System.out.println("Current time is " + view.toString());
    }
    
}
